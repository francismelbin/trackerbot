import logging
import os

from webexpythonsdk.models.cards import (
    Colors, TextBlock, FontWeight, FontSize, Column,
    AdaptiveCard, ColumnSet, HorizontalAlignment, ChoiceSet, Choice
)
from webexpythonsdk.models.cards.actions import Submit

from webex_bot.formatting import quote_info
from webex_bot.models.command import Command
from webex_bot.models.response import response_from_adaptive_card

# Reuse checkin posting helper
from checkin_command import (
    CheckInMarkCompleteCallback,
    post_checkin_to_space,
    _is_direct_message,
)

# Reuse training card builder
from training_command import (
    TrainingCommand,
    _load_data,
    _ensure_all_engineers,
    _save_data,
    _build_checkpoint_card,
    _get_space_members,
    _load_excluded_emails,
    _get_all_space_members_raw,
    _build_exclude_list_block,
    _members_cache,
    UpdateTrainingLinkCallback,
    SaveTrainingLinkCallback,
    ManageExcludeListCallback,
    SaveExcludeListCallback,
    MarkSelfCompletedCallback,
    TrainingStatusCallback,
    RemainingEngineersCallback,
    BackToTrainingCardCallback,
    RefreshMembersCallback,
)

from webexpythonsdk.models.cards import TextBlock, Colors, FontSize, FontWeight

log = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Dropdown selection card
# ─────────────────────────────────────────────

def _build_track_selector_card() -> object:
    title = TextBlock(
        "📊 T-Tracker",
        weight=FontWeight.BOLDER,
        size=FontSize.LARGE,
        horizontalAlignment=HorizontalAlignment.CENTER,
        color=Colors.WARNING,
    )
    subtitle = TextBlock(
        "Select a tracking option below:",
        wrap=True,
        color=Colors.DARK,
        horizontalAlignment=HorizontalAlignment.CENTER,
    )
    sep = TextBlock("─" * 40, color=Colors.LIGHT)

    dropdown = ChoiceSet(
        id="track_selection",
        choices=[
            Choice(title="📚  Training",          value="training"),
            Choice(title="🏢  Teams Check-In",    value="checkin"),
        ],
        value="training",       # default selection
        placeholder="Select an option…",
        style="compact",        # renders as a dropdown
    )

    body = [
        ColumnSet(columns=[Column(items=[title],    width=2)]),
        ColumnSet(columns=[Column(items=[subtitle], width=2)]),
        ColumnSet(columns=[Column(items=[sep],      width=2)]),
        ColumnSet(columns=[Column(items=[dropdown], width=2)]),
    ]

    go_btn = Submit(
        title="Go ➜",
        data={"callback_keyword": "track_selection_callback"},
    )
    card = AdaptiveCard(body=body, actions=[go_btn])
    return response_from_adaptive_card(card)


# ─────────────────────────────────────────────
# TrackCommand  (entry point — keyword: track)
# ─────────────────────────────────────────────

class TrackCommand(Command):
    """
    Triggered by typing  'track'  in the space or DM.
    Shows a dropdown with:
      1. Training
      2. Teams Check-In
    """

    def __init__(self):
        super().__init__(
            command_keyword="track",
            help_message="T-Tracker — Training & Teams Check-In",
            delete_previous_message=True,
            chained_commands=[
                TrackSelectionCallback(),
                # ── Training sub-commands (re-registered under track) ──
                UpdateTrainingLinkCallback(),
                SaveTrainingLinkCallback(),
                ManageExcludeListCallback(),
                SaveExcludeListCallback(),
                MarkSelfCompletedCallback(),
                TrainingStatusCallback(),
                RemainingEngineersCallback(),
                BackToTrainingCardCallback(),
                RefreshMembersCallback(),
                # ── Check-in sub-command ──
                CheckInMarkCompleteCallback(),
            ],
        )

    def execute(self, message, attachment_actions, activity):
        return _build_track_selector_card()


# ─────────────────────────────────────────────
# Selection callback — routes to the right flow
# ─────────────────────────────────────────────

class TrackSelectionCallback(Command):
    """
    Receives the dropdown choice and routes to
    Training tracker  OR  Teams Check-In card.
    """

    def __init__(self):
        super().__init__(
            card_callback_keyword="track_selection_callback",
            delete_previous_message=True,
        )

    def execute(self, message, attachment_actions, activity):
        inputs    = attachment_actions.inputs or {}
        selection = inputs.get("track_selection", "").strip().lower()
        is_direct = _is_direct_message(activity)

        log.info(f"[TrackSelection] User chose: '{selection}'")

        # ── Training ──────────────────────────────────────
        if selection == "training":
            _members_cache["last_fetched"] = None
            _members_cache["members"]      = []

            data = _load_data()
            data = _ensure_all_engineers(data)
            _save_data(data)

            if data.get("training_link", "").strip():
                return _build_checkpoint_card(data, is_direct=is_direct)

            # No link set yet — reuse the same "no link" UI from TrainingCommand
            from webexpythonsdk.models.cards import Text
            title = TextBlock(
                "📋 Training & Certification Tracker",
                weight=FontWeight.BOLDER,
                size=FontSize.LARGE,
                horizontalAlignment=HorizontalAlignment.CENTER,
                color=Colors.DARK,
            )
            members    = _get_space_members()
            excluded   = _load_excluded_emails()
            all_raw    = _get_all_space_members_raw()

            member_info = TextBlock(
                f"**👥 {len(members)} team member(s) detected in this space.**",
                wrap=True, color=Colors.GOOD,
            )
            member_list = TextBlock(
                "**Members:** " + (
                    ", ".join(m["name"] for m in members)
                    if members else "⚠️ No members found."
                ),
                wrap=True, color=Colors.DARK,
            )
            body = [
                ColumnSet(columns=[Column(items=[title], width=2)]),
                ColumnSet(columns=[Column(items=[member_info, member_list], width=2)]),
            ]

            if is_direct:
                subtitle = TextBlock(
                    "No training link set yet. Click below to set one up.",
                    wrap=True, isSubtle=True,
                    horizontalAlignment=HorizontalAlignment.CENTER,
                )
                body.insert(1, ColumnSet(columns=[Column(items=[subtitle], width=2)]))
                body.extend(_build_exclude_list_block(excluded, all_raw))
                card = AdaptiveCard(
                    body=body,
                    actions=[
                        Submit(title="🔗 Update Training Link",
                               data={"callback_keyword": "update_training_link_callback"}),
                        Submit(title="🚫 Manage Exclude List",
                               data={"callback_keyword": "manage_exclude_list_callback"}),
                    ],
                )
            else:
                subtitle = TextBlock(
                    "No training link set. Please ask the admin to set one "
                    "via direct message to the bot.",
                    wrap=True, isSubtle=True,
                    horizontalAlignment=HorizontalAlignment.CENTER,
                )
                body.append(ColumnSet(columns=[Column(items=[subtitle], width=2)]))
                card = AdaptiveCard(body=body)

            return response_from_adaptive_card(card)

        # ── Teams Check-In ────────────────────────────────
        elif selection == "checkin":
            # Post the interactive check-in card to the space
            post_checkin_to_space()

            # Return a brief acknowledgement to the person who triggered it
            ack = TextBlock(
                "✅ Teams Space Check-In card has been posted to the space.\n\n"
                "All team members have been asked to complete the check-in "
                "and mark themselves as done.",
                wrap=True,
                color=Colors.GOOD,
                weight=FontWeight.BOLDER,
            )
            return response_from_adaptive_card(
                AdaptiveCard(
                    body=[ColumnSet(columns=[Column(items=[ack], width=2)])]
                )
            )

        # ── Fallback ──────────────────────────────────────
        else:
            return quote_info(
                "⚠️ No option selected. Please type `track` and choose an option."
            )
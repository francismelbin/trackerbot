import os

os.environ["HTTPS_PROXY"] = "http://proxy.esl.cisco.com:80"
os.environ["HTTP_PROXY"]  = "http://proxy.esl.cisco.com:80"
os.environ["NO_PROXY"]    = "localhost,127.0.0.1,.cisco.com"

import asyncio
import sys
import logging

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from webex_bot.webex_bot import WebexBot
from webex_bot.commands.echo import EchoCommand

# Keep legacy 'training' command for backward compatibility
from training_command import TrainingCommand

# New unified 'track' command
from track_command import TrackCommand

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

proxies = {
    "https": "http://proxy.esl.cisco.com:80",
    "wss":   "socks5://proxy.esl.cisco.com:1080",
}

BOT_ACCESS_TOKEN = os.getenv("WEBEX_ACCESS_TOKEN")
ROOM_ID = os.getenv(
    "WEBEX_ROOM_ID",
    "Y2lzY29zcGFyazovL3VzL1JPT00vM2M5MjE1NTAtNWYzOC0xMWYxLWFhNDktMGJmZjRjYzFhMWEy",
)

bot = WebexBot(
    teams_bot_token=BOT_ACCESS_TOKEN,
    approved_rooms=[ROOM_ID],
    bot_name="T-Tracker",
    include_demo_commands=True,
    proxies=proxies,
)

bot.add_command(EchoCommand())
bot.add_command(TrainingCommand())   # legacy — keeps 'training' keyword working
bot.add_command(TrackCommand())      # new unified entry point

if __name__ == "__main__":
    log.info("Starting T-Tracker Bot...")

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(bot.run())
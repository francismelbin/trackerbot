import logging
import json
import os
import threading
from datetime import datetime

from webexpythonsdk import WebexAPI
from webexpythonsdk.models.cards import (
    Colors, TextBlock, FontWeight, FontSize, Column,
    AdaptiveCard, ColumnSet, HorizontalAlignment
)
from webexpythonsdk.models.cards.actions import Submit

from webex_bot.formatting import quote_info
from webex_bot.models.command import Command
from webex_bot.models.response import response_from_adaptive_card

log = logging.getLogger(__name__)

CHECKIN_DATA_FILE = "checkin_data.json"
TEAMS_CHECKIN_URL = (
    "https://teamspace.cisco.com/sso/cisco/redirect/"
    "L215Y2hlY2tpbnMvd2l6YXJk"
)

ROOM_ID           = os.getenv("WEBEX_ROOM_ID", "")
BOT_ACCESS_TOKEN  = os.getenv("WEBEX_ACCESS_TOKEN", "")

# ─────────────────────────────────────────────
# Shared member cache (reused from training)
# ─────────────────────────────────────────────
_ci_members_cache = {
    "members":      [],
    "last_fetched": None,
    "cache_ttl":    300,
}


def _is_direct_message(activity):
    try:
        if isinstance(activity, dict):
            tags = activity.get("target", {}).get("tags", [])
            return "ONE_ON_ONE" in tags
    except Exception:
        pass
    return False


# ─────────────────────────────────────────────
# Member helpers
# ─────────────────────────────────────────────

def _get_checkin_members(force_refresh=False):
    """Fetch human, non-bot space members (same logic as training_command)."""
    now = datetime.now()
    cache = _ci_members_cache
    if (
        not force_refresh
        and cache["last_fetched"]
        and cache["members"]
        and (now - cache["last_fetched"]).total_seconds() < cache["cache_ttl"]
    ):
        return cache["members"]

    members = []
    try:
        api  = WebexAPI(access_token=BOT_ACCESS_TOKEN)
        me   = api.people.me()
        bot_email = me.emails[0].lower() if me.emails else ""
        bot_name  = me.displayName or ""

        for membership in api.memberships.list(roomId=ROOM_ID):
            person_email = (membership.personEmail or "").strip()
            person_id    = membership.personId
            display_name = membership.personDisplayName or person_email.split("@")[0]

            if person_email.lower() == bot_email:
                continue
            if bot_name and display_name == bot_name:
                continue

            is_bot = person_email.lower().endswith("@webex.bot")
            if not is_bot:
                try:
                    p = api.people.get(person_id)
                    if getattr(p, "type", "").lower() == "bot":
                        is_bot = True
                except Exception:
                    pass
            if is_bot:
                continue

            members.append({"name": display_name, "email": person_email})

        log.info(f"[CheckIn] Fetched {len(members)} members.")
    except Exception as e:
        log.error(f"[CheckIn] Failed to fetch members: {e}")
        if cache["members"]:
            return cache["members"]

    cache["members"]      = members
    cache["last_fetched"] = now
    return members


# ─────────────────────────────────────────────
# Persistence helpers
# ─────────────────────────────────────────────

def _load_checkin_data() -> dict:
    """
    Schema:
    {
      "engineers": {
        "<display_name>": {
          "email": "...",
          "completed": false,
          "completed_at": ""
        }
      }
    }
    """
    if os.path.exists(CHECKIN_DATA_FILE):
        with open(CHECKIN_DATA_FILE, "r") as f:
            return json.load(f)
    return {"engineers": {}}


def _save_checkin_data(data: dict):
    with open(CHECKIN_DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _sync_checkin_members(data: dict) -> dict:
    """Add new members / remove stale members from check-in tracking."""
    if "engineers" not in data:
        data["engineers"] = {}

    current = _get_checkin_members(force_refresh=True)
    current_names = {m["name"] for m in current}

    # Remove stale
    for name in list(data["engineers"]):
        if name not in current_names:
            log.info(f"[CheckIn] Removing stale member: {name}")
            del data["engineers"][name]

    # Add new
    for m in current:
        if m["name"] not in data["engineers"]:
            data["engineers"][m["name"]] = {
                "email":        m["email"],
                "completed":    False,
                "completed_at": "",
            }
        else:
            data["engineers"][m["name"]]["email"] = m["email"]

    return data


# ─────────────────────────────────────────────
# Card builder
# ─────────────────────────────────────────────

def _build_checkin_card(data: dict) -> object:
    engineers = data.get("engineers", {})
    completed_count = sum(1 for e in engineers.values() if e.get("completed"))
    pending_count   = len(engineers) - completed_count

    title = TextBlock(
        "🏢 Teams Space Check-In",
        weight=FontWeight.BOLDER,
        size=FontSize.LARGE,
        horizontalAlignment=HorizontalAlignment.CENTER,
        color=Colors.WARNING,
    )
    intro = TextBlock(
        "Hi Team! 👋  Please complete the **Teams Space Check-In** "
        "and click **Mark as Complete** once done.",
        wrap=True,
        color=Colors.DARK,
        weight=FontWeight.BOLDER,
    )
    link_block = TextBlock(
        f"**Check-In Link:** [{TEAMS_CHECKIN_URL}]({TEAMS_CHECKIN_URL})",
        wrap=True,
        color=Colors.DARK,
    )
    sep = TextBlock("─" * 40, color=Colors.LIGHT)
    status_block = TextBlock(
        f"📊 Status: **{completed_count} completed** | **{pending_count} pending**",
        wrap=True,
        color=Colors.DARK,
        weight=FontWeight.BOLDER,
    )

    body = [
        ColumnSet(columns=[Column(items=[title],        width=2)]),
        ColumnSet(columns=[Column(items=[intro],        width=2)]),
        ColumnSet(columns=[Column(items=[link_block],   width=2)]),
        ColumnSet(columns=[Column(items=[sep],          width=2)]),
        ColumnSet(columns=[Column(items=[status_block], width=2)]),
    ]

    mark_btn = Submit(
        title="✅ Mark as Complete",
        data={"callback_keyword": "checkin_mark_complete_callback"},
        style="positive",
    )
    card = AdaptiveCard(body=body, actions=[mark_btn])
    return response_from_adaptive_card(card)


# ─────────────────────────────────────────────
# Post check-in card to the space (used by
# TrackCommand when "checkin" is selected)
# ─────────────────────────────────────────────

def post_checkin_to_space():
    """
    Posts the check-in adaptive card directly to the Webex space.
    Called from TrackCommand after dropdown selection.
    """
    try:
        api  = WebexAPI(access_token=BOT_ACCESS_TOKEN)
        data = _load_checkin_data()
        data = _sync_checkin_members(data)
        _save_checkin_data(data)

        engineers = data.get("engineers", {})

        card_dict = {
            "type":    "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "body": [
                {
                    "type":                  "TextBlock",
                    "text":                  "🏢 Teams Space Check-In",
                    "weight":                "Bolder",
                    "size":                  "Large",
                    "color":                 "Warning",
                    "horizontalAlignment":   "Center",
                },
                {
                    "type": "TextBlock",
                    "text": (
                        "Hi Team! 👋  Please complete the **Teams Space Check-In** "
                        "and click **Mark as Complete** once done."
                    ),
                    "wrap":   True,
                    "weight": "Bolder",
                },
                {
                    "type": "TextBlock",
                    "text": f"**Check-In Link:** [{TEAMS_CHECKIN_URL}]({TEAMS_CHECKIN_URL})",
                    "wrap": True,
                },
                {"type": "TextBlock", "text": "─" * 40, "color": "Light"},
                {
                    "type":   "TextBlock",
                    "text":   f"👥 **{len(engineers)} member(s) to complete check-in.**",
                    "wrap":   True,
                    "weight": "Bolder",
                },
                {"type": "TextBlock", "text": "─" * 40, "color": "Light"},
            ],
            "actions": [
                {
                    "type":  "Action.Submit",
                    "title": "✅ Mark as Complete",
                    "style": "positive",
                    "data":  {"callback_keyword": "checkin_mark_complete_callback"},
                }
            ],
        }

        api.messages.create(
            roomId=ROOM_ID,
            text="Teams Space Check-In — please complete and mark as done.",
            attachments=[{
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content":     card_dict,
            }],
        )
        log.info(f"[CheckIn] Card posted to room {ROOM_ID}.")
    except Exception as e:
        log.error(f"[CheckIn] Failed to post card to space: {e}")


# ─────────────────────────────────────────────
# Post @mention reminder to pending engineers
# ─────────────────────────────────────────────

def _mention_pending(data: dict):
    pending = {
        n: i for n, i in data.get("engineers", {}).items()
        if not i.get("completed")
    }
    if not pending:
        return

    try:
        api   = WebexAPI(access_token=BOT_ACCESS_TOKEN)
        parts = []
        for name, info in pending.items():
            email = info.get("email", "")
            parts.append(
                f"<@personEmail:{email}|{name}>" if email else f"**{name}**"
            )

        if len(parts) == 1:
            mentions = parts[0]
        elif len(parts) == 2:
            mentions = f"{parts[0]} and {parts[1]}"
        else:
            mentions = ", ".join(parts[:-1]) + " and " + parts[-1]

        api.messages.create(
            roomId=ROOM_ID,
            markdown=(
                f"Hi {mentions},\n\n"
                "⏰ A friendly reminder to complete the **Teams Space Check-In** "
                "and click **Mark as Complete** on the card above.\n\n"
                f"👉 **Link:** [{TEAMS_CHECKIN_URL}]({TEAMS_CHECKIN_URL})"
            ),
        )
        log.info(f"[CheckIn] @mentioned {len(pending)} pending member(s).")
    except Exception as e:
        log.error(f"[CheckIn] Failed to mention pending members: {e}")


# ─────────────────────────────────────────────
# Post "all completed" celebration message
# ─────────────────────────────────────────────

def _post_all_completed():
    try:
        api = WebexAPI(access_token=BOT_ACCESS_TOKEN)
        api.messages.create(
            roomId=ROOM_ID,
            markdown=(
                "🎉 **Congratulations team on completing the Teams Space Check-In!** 🎉\n\n"
                "All members have successfully completed the check-in. Great work everyone! 👏"
            ),
        )
        log.info("[CheckIn] All-completed celebration message posted.")
    except Exception as e:
        log.error(f"[CheckIn] Failed to post all-completed message: {e}")


# ─────────────────────────────────────────────
# Mark as Complete Callback
# ─────────────────────────────────────────────

class CheckInMarkCompleteCallback(Command):
    """Handles the 'Mark as Complete' button click on the check-in card."""

    def __init__(self):
        super().__init__(
            card_callback_keyword="checkin_mark_complete_callback",
            delete_previous_message=True,
        )

    # ── extract actor identity ──
    def _get_actor(self, activity, attachment_actions):
        name  = None
        email = None
        try:
            if isinstance(activity, dict):
                actor = activity.get("actor", {}) or {}
                name  = actor.get("displayName")
                email = actor.get("emailAddress") or actor.get("email")
                if not email and isinstance(actor.get("emails"), list):
                    email = (actor["emails"] or [None])[0]
        except Exception as e:
            log.error(f"[CheckIn] Actor extract error: {e}")

        if not email:
            try:
                email = (
                    getattr(attachment_actions, "personEmail", None)
                    or getattr(attachment_actions, "person_email", None)
                )
            except Exception:
                pass

        return name, email

    def execute(self, message, attachment_actions, activity):
        data = _load_checkin_data()
        data = _sync_checkin_members(data)
        engineers = data["engineers"]

        actor_name, actor_email = self._get_actor(activity, attachment_actions)
        log.info(f"[CheckIn] Mark complete — name='{actor_name}' email='{actor_email}'")

        # ── Match actor to tracked member ──
        matched_name = None
        if actor_email:
            for name, info in engineers.items():
                if info.get("email", "").lower() == actor_email.lower():
                    matched_name = name
                    break
        if not matched_name and actor_name and actor_name in engineers:
            matched_name = actor_name

        # ── Actor not found ──
        if not matched_name:
            msg = TextBlock(
                f"⚠️ Could not identify you (**{actor_name or 'Unknown'}** / "
                f"{actor_email or 'no email'}) as a tracked space member.\n\n"
                "Please contact your admin.",
                wrap=True,
                color=Colors.WARNING,
                weight=FontWeight.BOLDER,
            )
            return response_from_adaptive_card(
                AdaptiveCard(body=[ColumnSet(columns=[Column(items=[msg], width=2)])])
            )

        # ── Already completed ──
        if engineers[matched_name].get("completed"):
            done_at = engineers[matched_name].get("completed_at", "")
            try:
                done_at = datetime.fromisoformat(done_at).strftime("%Y-%m-%d %H:%M")
            except Exception:
                pass

            msg = TextBlock(
                f"**{matched_name}**, you already completed the Teams Space Check-In "
                f"on **{done_at}**. ✅\n\nThank you!",
                wrap=True,
                color=Colors.WARNING,
                weight=FontWeight.BOLDER,
            )
            pending_note = TextBlock(
                "Other engineers — please click below to mark your completion.",
                wrap=True,
                color=Colors.DARK,
            )
            sep = TextBlock("─" * 40, color=Colors.LIGHT)
            mark_btn = Submit(
                title="✅ Mark as Complete",
                data={"callback_keyword": "checkin_mark_complete_callback"},
                style="positive",
            )
            return response_from_adaptive_card(
                AdaptiveCard(
                    body=[
                        ColumnSet(columns=[Column(items=[msg],          width=2)]),
                        ColumnSet(columns=[Column(items=[sep],          width=2)]),
                        ColumnSet(columns=[Column(items=[pending_note], width=2)]),
                    ],
                    actions=[mark_btn],
                )
            )

        # ── Record completion ──
        engineers[matched_name]["completed"]    = True
        engineers[matched_name]["completed_at"] = datetime.now().isoformat()
        _save_checkin_data(data)
        log.info(f"[CheckIn] {matched_name} marked as complete.")

        # ── Check if ALL done ──
        all_done = all(e.get("completed") for e in engineers.values())

        if all_done:
            # Post celebration and return confirmation card
            _post_all_completed()

            celebrate = TextBlock(
                "🎉 Congratulations team on completing the Teams Space Check-In!",
                wrap=True,
                color=Colors.GOOD,
                weight=FontWeight.BOLDER,
                size=FontSize.MEDIUM,
                horizontalAlignment=HorizontalAlignment.CENTER,
            )
            return response_from_adaptive_card(
                AdaptiveCard(
                    body=[ColumnSet(columns=[Column(items=[celebrate], width=2)])]
                )
            )

        # ── Tag remaining engineers ──
        _mention_pending(data)

        # ── Return updated card ──
        return _build_checkin_card(data)
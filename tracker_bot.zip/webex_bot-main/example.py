import asyncio
import sys
import os
import logging

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from webex_bot.webex_bot import WebexBot
from webex_bot.commands.echo import EchoCommand
from training_command import TrainingCommand, TrainingReminderScheduler

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

proxies = {
    'https': 'http://proxy.esl.cisco.com:80',
    'wss': 'socks5://proxy.esl.cisco.com:1080'
}

bot = WebexBot(
    teams_bot_token=os.getenv("WEBEX_ACCESS_TOKEN"),
    approved_rooms=['06586d8d-6aad-4201-9a69-0bf9eeb5766e','Y2lzY29zcGFyazovL3VzL1JPT00vODM0NjE1MDAtM2Q4Yy0xMWYxLWEyZTAtMjE5M2U1NzRjNzUw'],
    bot_name="training",
    include_demo_commands=True,
    proxies=proxies
)

bot.add_command(EchoCommand())
bot.add_command(TrainingCommand())

try:
    from webexpythonsdk import WebexAPI
    webex_api = WebexAPI(
        access_token='YTkyNWQ0OWQtYjdjYy00YjY5LTgwYmUtYmVhZTcyMmYyNmQ5OWNhN2FjMzAtODMw_PF84_1eb65fdf-9643-417f-9974-ad72cae0e10f'
    )
    scheduler = TrainingReminderScheduler(
        webex_api=webex_api,
        room_id='Y2lzY29zcGFyazovL3VzL1JPT00vMjNhOGIzMTAtM2Q4MS0xMWYxLThhYmMtNjlkMDhhZDQyNGU5'
    )
    scheduler.start()
except Exception as e:
    log.warning(f"Could not start reminder scheduler: {e}")

if __name__ == "__main__":
    log.info("Starting Training Tracker Bot...")

loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)

loop.run_until_complete(bot.run())
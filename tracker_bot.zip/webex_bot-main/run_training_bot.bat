@echo off
:: Change directory to the location of the script
cd /d "C:\Learning\webex_bot-main\main_training.py"

:: Run the python script using the provided executable path
"C:\Learning\python3.exe" main_training.py

:: Keep the window open after execution
pause
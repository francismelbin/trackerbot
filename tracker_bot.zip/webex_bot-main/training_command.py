import logging
import json
import os
import threading
import schedule
import time
import io
import datetime
from datetime import datetime
from openpyxl.utils import get_column_letter

from openpyxl import Workbook
from openpyxl.styles import (
    PatternFill, Font, Alignment, Border, Side
)

from webexpythonsdk import WebexAPI
from webexpythonsdk.models.cards import (
    Colors, TextBlock, FontWeight, FontSize, Column, AdaptiveCard, ColumnSet,
    Text, Image, HorizontalAlignment, Toggle
)
from webexpythonsdk.models.cards import actions
from webexpythonsdk.models.cards.actions import Submit

from webex_bot.formatting import quote_info
from webex_bot.models.command import Command
from webex_bot.models.response import response_from_adaptive_card

log = logging.getLogger(__name__)

DATA_FILE = "training_data.json"

ROOM_ID = os.getenv(
    "WEBEX_ROOM_ID",
    "Y2lzY29zcGFyazovL3VzL1JPT00vM2M5MjE1NTAtNWYzOC0xMWYxLWFhNDktMGJmZjRjYzFhMWEy"
)
BOT_ACCESS_TOKEN = os.getenv("WEBEX_ACCESS_TOKEN", "")

_members_cache = {
    "members": [],
    "last_fetched": None,
    "cache_ttl_seconds": 300
}

# ──────────────────────────────────────────────
# Exclude list helpers (persisted in DATA_FILE)
# ──────────────────────────────────────────────

def _load_excluded_emails() -> set:
    """Load the persisted exclude list from data file."""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            data = json.load(f)
        return set(e.lower() for e in data.get("excluded_emails", []))
    return set()


def _save_excluded_emails(excluded: set):
    """Persist the exclude list into the data file."""
    data = _load_data_raw()
    data["excluded_emails"] = list(excluded)
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _load_data_raw() -> dict:
    """Load JSON without any member sync (used internally)."""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {
        "training_link": "",
        "training_details": "",
        "excluded_emails": [],
        "engineers": {}
    }


def _is_direct_message(activity):
    """Check if the message is from a 1-on-1 (direct) conversation."""
    try:
        if isinstance(activity, dict):
            tags = activity.get("target", {}).get("tags", [])
            return "ONE_ON_ONE" in tags
    except Exception:
        pass
    return False


# ──────────────────────────────────────────────
# Space member fetcher
# ──────────────────────────────────────────────

def _get_space_members(force_refresh=False):
    """
    Fetch space members, excluding:
      - The T-Tracker bot itself
      - Any other bot accounts
      - Emails in the persisted excluded_emails list
    """
    now = datetime.now()

    if (not force_refresh
            and _members_cache["last_fetched"]
            and _members_cache["members"]
            and (now - _members_cache["last_fetched"]).total_seconds()
                < _members_cache["cache_ttl_seconds"]):
        return _members_cache["members"]

    excluded_emails = _load_excluded_emails()
    members = []

    try:
        api = WebexAPI(access_token=BOT_ACCESS_TOKEN)
        me = api.people.me()
        bot_email = me.emails[0].lower() if me.emails else ""
        bot_name  = me.displayName or ""

        memberships = api.memberships.list(roomId=ROOM_ID)

        for membership in memberships:
            person_email = (membership.personEmail or "").strip()
            person_id    = membership.personId
            display_name = membership.personDisplayName or person_email.split("@")[0]

            # 1) Skip the bot itself
            if person_email.lower() == bot_email:
                continue
            if bot_name and display_name == bot_name:
                continue

            # 2) Skip excluded users
            if person_email.lower() in excluded_emails:
                log.info(f"Skipping excluded user: {display_name} ({person_email})")
                continue

            # 3) Skip all bot accounts
            is_bot = False
            if person_email.lower().endswith("@webex.bot"):
                is_bot = True
            else:
                try:
                    person = api.people.get(person_id)
                    if getattr(person, "type", "").lower() == "bot":
                        is_bot = True
                except Exception as e:
                    log.debug(f"Could not fetch person type for {person_email}: {e}")

            if is_bot:
                log.info(f"Skipping bot account: {display_name} ({person_email})")
                continue

            members.append({"name": display_name, "email": person_email})

        log.info(
            f"Fetched {len(members)} eligible members "
            f"(excluded {len(excluded_emails)} user(s))"
        )

    except Exception as e:
        log.error(f"Failed to fetch space members: {e}")
        if _members_cache["members"]:
            return _members_cache["members"]

    _members_cache["members"]      = members
    _members_cache["last_fetched"] = now
    return members


def _get_all_space_members_raw():
    """
    Fetch ALL human members (no exclude-list filter applied).
    Used to populate the exclude-list UI so admins can pick whom to exclude.
    """
    members = []
    try:
        api = WebexAPI(access_token=BOT_ACCESS_TOKEN)
        me  = api.people.me()
        bot_email = me.emails[0].lower() if me.emails else ""
        bot_name  = me.displayName or ""

        memberships = api.memberships.list(roomId=ROOM_ID)
        for membership in memberships:
            person_email = (membership.personEmail or "").strip()
            person_id    = membership.personId
            display_name = membership.personDisplayName or person_email.split("@")[0]

            if person_email.lower() == bot_email:
                continue
            if bot_name and display_name == bot_name:
                continue

            is_bot = False
            if person_email.lower().endswith("@webex.bot"):
                is_bot = True
            else:
                try:
                    person = api.people.get(person_id)
                    if getattr(person, "type", "").lower() == "bot":
                        is_bot = True
                except Exception:
                    pass
            if is_bot:
                continue

            members.append({"name": display_name, "email": person_email})
    except Exception as e:
        log.error(f"Failed to fetch raw space members: {e}")
    return members


# ──────────────────────────────────────────────
# Data helpers
# ──────────────────────────────────────────────

def _load_data():
    data = _load_data_raw()
    if "excluded_emails" not in data:
        data["excluded_emails"] = []
    if "engineers" not in data:
        data["engineers"] = {}
    if "training_link" not in data:
        data["training_link"] = ""
    if "training_details" not in data:
        data["training_details"] = ""
    return data


def _fresh_data(excluded_emails: list = None):
    if excluded_emails is None:
        excluded_emails = list(_load_excluded_emails())

    engineers = {}
    for member in _get_space_members():
        engineers[member["name"]] = {
            "email": member["email"],
            "completed": False,
            "updated_at": ""
        }
    return {
        "training_link": "",
        "training_details": "",
        "excluded_emails": excluded_emails,
        "engineers": engineers
    }


def _save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _ensure_all_engineers(data):
    if "engineers" not in data:
        data["engineers"] = {}

    current_members = _get_space_members()
    current_names   = {m["name"] for m in current_members}

    stale_names = [n for n in data["engineers"] if n not in current_names]
    for name in stale_names:
        log.info(f"Removing stale member from tracking: {name}")
        del data["engineers"][name]

    for member in current_members:
        if member["name"] not in data["engineers"]:
            log.info(f"Adding new member to tracking: {member['name']}")
            data["engineers"][member["name"]] = {
                "email": member["email"],
                "completed": False,
                "updated_at": ""
            }
        else:
            data["engineers"][member["name"]]["email"] = member["email"]

    return data


def _format_link(link):
    if link and link.strip() and link != "Not set":
        return f"[{link}]({link})"
    return "Not set"


# ──────────────────────────────────────────────
# Exclude list summary block (reused in cards)
# ──────────────────────────────────────────────

def _build_exclude_list_block(excluded_emails: set, all_members: list) -> list:
    """
    Returns a list of TextBlock items showing the current exclude list.
    Resolves emails to display names where possible.
    """
    blocks = []
    email_to_name = {m["email"].lower(): m["name"] for m in all_members}

    separator = TextBlock("─" * 40, color=Colors.LIGHT)
    blocks.append(ColumnSet(columns=[Column(items=[separator], width=2)]))

    header = TextBlock(
        f"🚫 Exclude List ({len(excluded_emails)} member(s) excluded from tracking):",
        weight=FontWeight.BOLDER, color=Colors.WARNING, wrap=True
    )
    blocks.append(ColumnSet(columns=[Column(items=[header], width=2)]))

    if excluded_emails:
        for email in sorted(excluded_emails):
            display = email_to_name.get(email, email)
            row = TextBlock(f"• {display} ({email})", wrap=True, color=Colors.DARK)
            blocks.append(ColumnSet(columns=[Column(items=[row], width=2)]))
    else:
        blocks.append(ColumnSet(columns=[Column(items=[
            TextBlock(
                "  No members excluded — all space members are tracked.",
                wrap=True, color=Colors.GOOD
            )
        ], width=2)]))

    blocks.append(ColumnSet(columns=[Column(items=[separator], width=2)]))
    return blocks


# ──────────────────────────────────────────────
# Excel Report Generator
# ──────────────────────────────────────────────

def _generate_completion_excel(data: dict) -> bytes:
    """
    Generate a styled Excel workbook with the training completion status.
    Returns the workbook as bytes.
    """
    engineers        = data.get("engineers", {})
    training_link    = data.get("training_link", "Not set")
    training_details = data.get("training_details", "Not set")

    wb = Workbook()
    ws = wb.active
    ws.title = "Completion Status"

    # ── Colour palette ──
    CISCO_BLUE   = "004A98"   # Header background
    HEADER_FONT  = "FFFFFF"   # White header text
    GREEN_FILL   = "D9EAD3"   # Completed row
    RED_FILL     = "FCE4D6"   # Not completed row
    SUMMARY_FILL = "EAF4FB"   # Summary section
    BORDER_COLOR = "BFBFBF"

    thin = Side(style="thin", color=BORDER_COLOR)
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    # ── Helper: apply border to a row range ──
    def _apply_border(row_num, col_start, col_end):
        for col in range(col_start, col_end + 1):
            ws.cell(row=row_num, column=col).border = border

    # ─────────────────────────────────────
    # Row 1 – Report title
    # ─────────────────────────────────────
    ws.merge_cells("A1:E1")
    title_cell = ws["A1"]
    title_cell.value     = "Training & Certification Completion Report"
    title_cell.font      = Font(bold=True, size=14, color=HEADER_FONT)
    title_cell.fill      = PatternFill("solid", fgColor=CISCO_BLUE)
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    # ─────────────────────────────────────
    # Rows 2-4 – Training meta information
    # ─────────────────────────────────────
    meta_rows = [
        ("Training Link:",    training_link),
        ("Training Details:", training_details),
        ("Report Generated:", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    ]
    for offset, (label, value) in enumerate(meta_rows, start=2):
        ws.cell(row=offset, column=1, value=label).font = Font(bold=True)
        ws.merge_cells(f"B{offset}:E{offset}")
        cell = ws.cell(row=offset, column=2, value=value)
        cell.alignment = Alignment(wrap_text=True)
        _apply_border(offset, 1, 5)

    # ─────────────────────────────────────
    # Row 5 – Blank spacer
    # ─────────────────────────────────────
    ws.row_dimensions[5].height = 8

    # ─────────────────────────────────────
    # Row 6 – Column headers
    # ─────────────────────────────────────
    HEADERS = ["#", "Name", "Email", "Status", "Completed On"]
    for col_idx, header in enumerate(HEADERS, start=1):
        cell = ws.cell(row=6, column=col_idx, value=header)
        cell.font      = Font(bold=True, color=HEADER_FONT)
        cell.fill      = PatternFill("solid", fgColor=CISCO_BLUE)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border    = border
    ws.row_dimensions[6].height = 20

    # ─────────────────────────────────────
    # Rows 7+ – Engineer data rows
    # ─────────────────────────────────────
    completed_count = 0
    pending_count   = 0

    for row_offset, (name, info) in enumerate(engineers.items(), start=7):
        is_completed = info.get("completed", False)
        completed_on = info.get("updated_at", "")

        if completed_on:
            try:
                completed_on = datetime.fromisoformat(completed_on).strftime("%Y-%m-%d %H:%M")
            except Exception:
                pass
        else:
            completed_on = "—"

        status_text = "✅ Completed" if is_completed else "❌ Pending"
        row_fill    = PatternFill("solid", fgColor=GREEN_FILL if is_completed else RED_FILL)

        if is_completed:
            completed_count += 1
        else:
            pending_count += 1

        row_data = [
            row_offset - 6,          # sequential number
            name,
            info.get("email", ""),
            status_text,
            completed_on if is_completed else "—",
        ]

        for col_idx, value in enumerate(row_data, start=1):
            cell = ws.cell(row=row_offset, column=col_idx, value=value)
            cell.fill      = row_fill
            cell.border    = border
            cell.alignment = Alignment(wrap_text=True, vertical="center")

        ws.row_dimensions[row_offset].height = 18

    # ─────────────────────────────────────
    # Summary rows (after data)
    # ─────────────────────────────────────
    total      = len(engineers)
    summary_row = 7 + total + 1       # one blank row gap

    ws.row_dimensions[summary_row - 1].height = 8   # spacer

    summary_data = [
        ("Total Tracked:",    total),
        ("Completed:",        completed_count),
        ("Pending:",          pending_count),
        ("Completion Rate:",  f"{(completed_count / total * 100):.1f}%" if total else "N/A"),
    ]
    summary_fill = PatternFill("solid", fgColor=SUMMARY_FILL)

    for offset, (label, value) in enumerate(summary_data):
        r = summary_row + offset
        ws.merge_cells(f"A{r}:B{r}")
        label_cell = ws.cell(row=r, column=1, value=label)
        label_cell.font      = Font(bold=True)
        label_cell.fill      = summary_fill
        label_cell.border    = border
        label_cell.alignment = Alignment(horizontal="right")

        ws.merge_cells(f"C{r}:E{r}")
        value_cell = ws.cell(row=r, column=3, value=value)
        value_cell.fill      = summary_fill
        value_cell.border    = border
        value_cell.alignment = Alignment(horizontal="center")

        # Fill remaining merged cells' borders
        for col in range(2, 6):
            ws.cell(row=r, column=col).border = border

    # ─────────────────────────────────────
    # Column widths
    # ─────────────────────────────────────
    col_widths = {1: 6, 2: 28, 3: 36, 4: 18, 5: 22}
    for col_num, width in col_widths.items():
        ws.column_dimensions[
            ws.cell(row=1, column=col_num).column_letter
        ].width = width

    # ── Freeze panes below header row ──
    ws.freeze_panes = "A7"

    # ── Save to bytes ──
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()


# ──────────────────────────────────────────────
# Main tracking card
# ──────────────────────────────────────────────

def _build_checkpoint_card(data, is_direct=False):
    training_link    = data.get("training_link", "Not set")
    training_details = data.get("training_details", "Not set")
    engineers        = data.get("engineers", {})
    excluded_emails  = set(e.lower() for e in data.get("excluded_emails", []))

    title = TextBlock(
        "Training & Certification Tracker",
        weight=FontWeight.BOLDER, size=FontSize.LARGE,
        horizontalAlignment=HorizontalAlignment.CENTER,
        color=Colors.WARNING
    )
    reminder = TextBlock(
        "Certificate Completion Alert!!!",
        wrap=True, color=Colors.GOOD,
        horizontalAlignment=HorizontalAlignment.CENTER,
        size=FontSize.LARGE, weight=FontWeight.BOLDER
    )
    link_text = TextBlock(
        "**Training Link:** " + _format_link(training_link),
        wrap=True, color=Colors.DARK
    )
    details_text = TextBlock(
        "**Training Details:** " + (training_details if training_details else "Not set"),
        wrap=True, color=Colors.DARK
    )
    member_count = TextBlock(
        "**Team Members Tracked:** " + str(len(engineers)),
        wrap=True, color=Colors.DARK
    )
    separator = TextBlock("----------------------------------------", color=Colors.LIGHT)
    instructions = TextBlock(
        'Click the "Mark as Completed" button below once you have finished the training',
        wrap=True, color=Colors.DARK
    )

    completed_count = sum(1 for e in engineers.values() if e.get("completed", False))
    pending_count   = len(engineers) - completed_count
    status_summary  = TextBlock(
        f"Status: {completed_count} completed | {pending_count} pending",
        wrap=True, color=Colors.DARK, weight=FontWeight.BOLDER
    )

    body_items = [
        ColumnSet(columns=[Column(items=[title],          width=2)]),
        ColumnSet(columns=[Column(items=[reminder],       width=2)]),
        ColumnSet(columns=[Column(items=[link_text],      width=2)]),
        ColumnSet(columns=[Column(items=[details_text],   width=2)]),
        ColumnSet(columns=[Column(items=[member_count],   width=2)]),
        ColumnSet(columns=[Column(items=[separator],      width=2)]),
        ColumnSet(columns=[Column(items=[instructions],   width=2)]),
        ColumnSet(columns=[Column(items=[status_summary], width=2)]),
    ]

    # ── Append exclude list summary when viewed by admin (DM) ──
    if is_direct:
        all_members = _get_all_space_members_raw()
        body_items.extend(_build_exclude_list_block(excluded_emails, all_members))

    # ── Actions ──
    card_actions = []

    # Always present
    completed_btn = Submit(
        title="Mark as Completed",
        data={"callback_keyword": "mark_self_completed_callback"},
        style="positive"
    )
    card_actions.append(completed_btn)

    # Admin-only buttons (DM context)
    if is_direct:
        view_status_btn = Submit(
            title="View Completion Status",
            data={"callback_keyword": "training_status_callback"}
        )
        card_actions.append(view_status_btn)

        remaining_btn = Submit(
            title="Remaining Engineers",
            data={"callback_keyword": "remaining_engineers_callback"}
        )
        card_actions.append(remaining_btn)

        update_link_btn = Submit(
            title="Update Training Link",
            data={"callback_keyword": "update_training_link_callback"}
        )
        card_actions.append(update_link_btn)

        manage_exclude_btn = Submit(
            title="🚫 Manage Exclude List",
            data={"callback_keyword": "manage_exclude_list_callback"}
        )
        card_actions.append(manage_exclude_btn)

    card = AdaptiveCard(body=body_items, actions=card_actions)
    return response_from_adaptive_card(card)


# ══════════════════════════════════════════════
# Main Command
# ══════════════════════════════════════════════

class TrainingCommand(Command):

    def __init__(self):
        super().__init__(
            command_keyword="training",
            help_message="Training & Certification Tracker",
            delete_previous_message=True,
            chained_commands=[
                UpdateTrainingLinkCallback(),
                SaveTrainingLinkCallback(),
                ManageExcludeListCallback(),
                SaveExcludeListCallback(),
                MarkSelfCompletedCallback(),
                TrainingStatusCallback(),
                RemainingEngineersCallback(),
                BackToTrainingCardCallback(),
                RefreshMembersCallback(),
                DownloadCompletionExcelCallback(),   # ← NEW
            ]
        )

    def execute(self, message, attachment_actions, activity):
        try:
            is_direct = _is_direct_message(activity)

            _members_cache["last_fetched"] = None
            _members_cache["members"]      = []

            data = _load_data()
            data = _ensure_all_engineers(data)
            _save_data(data)

            if data.get("training_link", "").strip():
                return _build_checkpoint_card(data, is_direct=is_direct)

            # ── No link set yet ──
            title = TextBlock(
                "📋 Training & Certification Tracker",
                weight=FontWeight.BOLDER, size=FontSize.LARGE,
                horizontalAlignment=HorizontalAlignment.CENTER, color=Colors.DARK
            )

            members  = _get_space_members()
            excluded = _load_excluded_emails()
            all_raw  = _get_all_space_members_raw()

            member_info = TextBlock(
                f"**👥 {len(members)} team members detected (tracked) in this space.**",
                wrap=True, color=Colors.GOOD
            )
            if members:
                member_list = TextBlock(
                    "**Members:** " + ", ".join(m["name"] for m in members),
                    wrap=True, color=Colors.DARK
                )
            else:
                member_list = TextBlock(
                    "⚠️ No members found. Make sure the bot is added to the correct space.",
                    wrap=True, color=Colors.GOOD
                )

            body = [
                ColumnSet(columns=[Column(items=[title], width=2)]),
                ColumnSet(columns=[Column(items=[member_info, member_list], width=2)]),
            ]

            if is_direct:
                subtitle = TextBlock(
                    "No training link has been set yet. Click below to set one up.",
                    wrap=True, isSubtle=True,
                    horizontalAlignment=HorizontalAlignment.CENTER
                )
                body.insert(1, ColumnSet(columns=[Column(items=[subtitle], width=2)]))
                body.extend(_build_exclude_list_block(excluded, all_raw))

                btn_update_link = Submit(
                    title="🔗 Update Training Link",
                    data={"callback_keyword": "update_training_link_callback"}
                )
                manage_exclude_btn = Submit(
                    title="🚫 Manage Exclude List",
                    data={"callback_keyword": "manage_exclude_list_callback"}
                )
                card = AdaptiveCard(body=body, actions=[btn_update_link, manage_exclude_btn])

            else:
                subtitle = TextBlock(
                    "No training link has been set yet. Please ask the admin to set up "
                    "a training link by messaging the bot directly (1-on-1).",
                    wrap=True, isSubtle=True,
                    horizontalAlignment=HorizontalAlignment.CENTER
                )
                admin_note = TextBlock(
                    "💡 **Tip:** To update the training link, message this bot directly "
                    "(not in the space). Only direct messages can update the training link.",
                    wrap=True, color=Colors.DARK
                )
                body.extend([
                    ColumnSet(columns=[Column(items=[subtitle],     width=2)]),
                    ColumnSet(columns=[Column(items=[admin_note],   width=2)]),
                ])
                card = AdaptiveCard(body=body)

            return response_from_adaptive_card(card)

        except Exception as e:
            log.error(f"Error in TrainingCommand.execute: {e}")
            return quote_info(f"❌ Error loading training tracker: {e}")


# ══════════════════════════════════════════════
# Manage Exclude List (standalone – DM only)
# ══════════════════════════════════════════════

class ManageExcludeListCallback(Command):
    """Show all space members as a toggle list; admin can pick who to exclude."""

    def __init__(self):
        super().__init__(
            card_callback_keyword="manage_exclude_list_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        is_direct = _is_direct_message(activity)
        if not is_direct:
            return quote_info(
                "🚫 Exclude list can only be managed via direct message (1-on-1) with the bot."
            )
        return _build_exclude_list_card()


def _build_exclude_list_card():
    """
    Build the exclude-list management card using a Toggle (checkbox) per member.
    Members that are ticked will be added to the exclude list on save.
    """
    all_members     = _get_all_space_members_raw()
    excluded_emails = _load_excluded_emails()

    title = TextBlock(
        "🚫 Manage Exclude List",
        weight=FontWeight.BOLDER, size=FontSize.LARGE,
        horizontalAlignment=HorizontalAlignment.CENTER, color=Colors.DARK
    )
    instructions = TextBlock(
        "Tick the members you want to **exclude** from training tracking, "
        "then click **Save Exclude List**. Ticked members will NOT be tracked.",
        wrap=True, color=Colors.DARK
    )
    separator = TextBlock("─" * 40, color=Colors.LIGHT)

    body_items = [
        ColumnSet(columns=[Column(items=[title],        width=2)]),
        ColumnSet(columns=[Column(items=[instructions], width=2)]),
        ColumnSet(columns=[Column(items=[separator],    width=2)]),
    ]

    if not all_members:
        body_items.append(ColumnSet(columns=[Column(items=[
            TextBlock(
                "⚠️ No members found in this space.",
                wrap=True, color=Colors.WARNING
            )
        ], width=2)]))
    else:
        for idx, m in enumerate(all_members):
            is_excluded = m["email"].lower() in excluded_emails
            toggle = Toggle(
                title=f"{m['name']}  ({m['email']})",
                id=f"exclude_{idx}",
                value="true" if is_excluded else "false",
                valueOn="true",
                valueOff="false"
            )
            body_items.append(ColumnSet(columns=[Column(items=[toggle], width=2)]))

    body_items.append(ColumnSet(columns=[Column(items=[separator], width=2)]))

    save_btn = Submit(
        title="💾 Save Exclude List",
        data={
            "callback_keyword": "save_exclude_list_callback",
            "email_map": {
                f"exclude_{i}": m["email"]
                for i, m in enumerate(all_members)
            }
        }
    )
    back_btn = Submit(
        title="🔙 Back",
        data={"callback_keyword": "back_to_training_card_callback"}
    )

    card = AdaptiveCard(body=body_items, actions=[save_btn, back_btn])
    return response_from_adaptive_card(card)


# ══════════════════════════════════════════════
# Save Exclude List
# ══════════════════════════════════════════════

class SaveExcludeListCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="save_exclude_list_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        is_direct = _is_direct_message(activity)
        if not is_direct:
            return quote_info("🚫 Exclude list can only be managed via DM.")

        inputs    = attachment_actions.inputs or {}
        email_map = inputs.get("email_map", {})

        new_excluded = set()
        for toggle_id, email in email_map.items():
            val = str(inputs.get(toggle_id, "false")).lower()
            if val == "true" and "@" in email:
                new_excluded.add(email.strip().lower())

        _save_excluded_emails(new_excluded)
        log.info(f"Exclude list updated via checkboxes: {new_excluded}")

        _members_cache["last_fetched"] = None
        _members_cache["members"]      = []

        data = _load_data()
        data = _ensure_all_engineers(data)
        _save_data(data)

        all_members = _get_all_space_members_raw()
        excluded    = _load_excluded_emails()

        confirm_title = TextBlock(
            "✅ Exclude List Saved",
            weight=FontWeight.BOLDER, size=FontSize.LARGE,
            horizontalAlignment=HorizontalAlignment.CENTER, color=Colors.GOOD
        )
        summary = TextBlock(
            f"**{len(new_excluded)} member(s) excluded** from training tracking.",
            wrap=True, color=Colors.DARK
        )
        tracked_count = len(_get_space_members())
        tracked_info  = TextBlock(
            f"**{tracked_count} member(s) will be tracked** for this training.",
            wrap=True, color=Colors.DARK
        )

        body_items = [
            ColumnSet(columns=[Column(items=[confirm_title], width=2)]),
            ColumnSet(columns=[Column(items=[summary],       width=2)]),
            ColumnSet(columns=[Column(items=[tracked_info],  width=2)]),
        ]
        body_items.extend(_build_exclude_list_block(excluded, all_members))

        back_btn = Submit(
            title="🔙 Back to Training Card",
            data={"callback_keyword": "back_to_training_card_callback"}
        )
        manage_btn = Submit(
            title="✏️ Edit Exclude List Again",
            data={"callback_keyword": "manage_exclude_list_callback"}
        )
        update_link_btn = Submit(
            title="🔗 Update Training Link",
            data={"callback_keyword": "update_training_link_callback"}
        )

        card = AdaptiveCard(
            body=body_items,
            actions=[back_btn, manage_btn, update_link_btn]
        )
        return response_from_adaptive_card(card)


# ══════════════════════════════════════════════
# Refresh Members
# ══════════════════════════════════════════════

class RefreshMembersCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="refresh_members_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        _members_cache["last_fetched"] = None
        _members_cache["members"]      = []

        data = _load_data()
        data = _ensure_all_engineers(data)
        _save_data(data)

        is_direct = _is_direct_message(activity)
        if data.get("training_link", "").strip():
            return _build_checkpoint_card(data, is_direct=is_direct)

        members = _get_space_members()
        return quote_info(
            f"🔄 **Members refreshed!** Found {len(members)} team members in the space.\n\n"
            "Type `training` to start tracking."
        )


# ══════════════════════════════════════════════
# Back to Training Card
# ══════════════════════════════════════════════

class BackToTrainingCardCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="back_to_training_card_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        data = _load_data()
        data = _ensure_all_engineers(data)
        _save_data(data)
        is_direct = _is_direct_message(activity)

        if data.get("training_link", "").strip():
            return _build_checkpoint_card(data, is_direct=is_direct)

        title = TextBlock(
            "📋 Training & Certification Tracker",
            weight=FontWeight.BOLDER, size=FontSize.LARGE,
            horizontalAlignment=HorizontalAlignment.CENTER, color=Colors.DARK
        )

        if is_direct:
            subtitle = TextBlock(
                "No training link has been set yet. Click below to set one up.",
                wrap=True, isSubtle=True,
                horizontalAlignment=HorizontalAlignment.CENTER
            )
            btn_update_link = Submit(
                title="🔗 Update Training Link",
                data={"callback_keyword": "update_training_link_callback"}
            )
            manage_exclude_btn = Submit(
                title="🚫 Manage Exclude List",
                data={"callback_keyword": "manage_exclude_list_callback"}
            )
            card = AdaptiveCard(
                body=[ColumnSet(columns=[Column(items=[title, subtitle], width=2)])],
                actions=[btn_update_link, manage_exclude_btn]
            )
        else:
            subtitle = TextBlock(
                "No training link has been set yet. Please message the bot directly to set one up.",
                wrap=True, isSubtle=True,
                horizontalAlignment=HorizontalAlignment.CENTER
            )
            card = AdaptiveCard(
                body=[ColumnSet(columns=[Column(items=[title, subtitle], width=2)])]
            )

        return response_from_adaptive_card(card)


# ══════════════════════════════════════════════
# Update Training Link Form (DM only)
# ══════════════════════════════════════════════

class UpdateTrainingLinkCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="update_training_link_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        is_direct = _is_direct_message(activity)
        if not is_direct:
            return quote_info(
                "🚫 **Training link can only be updated via direct message (1-on-1) with the bot.**\n\n"
                "Please message the bot directly to update the training link."
            )

        data        = _load_data()
        members     = _get_space_members()
        excluded    = _load_excluded_emails()
        all_members = _get_all_space_members_raw()

        title = TextBlock(
            "🔗 Update Training Link & Details",
            weight=FontWeight.BOLDER, size=FontSize.MEDIUM, color=Colors.DARK
        )
        warning = TextBlock(
            "⚠️ Note: Updating the training link will reset ALL completion "
            "statuses and start fresh tracking.",
            wrap=True, color=Colors.GOOD, weight=FontWeight.BOLDER
        )
        member_info = TextBlock(
            f"**👥 {len(members)} team member(s)** will be tracked "
            f"({len(excluded)} excluded).",
            wrap=True, color=Colors.DARK
        )

        current_link    = data.get("training_link", "")
        current_details = data.get("training_details", "")

        current_link_label = TextBlock(
            f"**Current Link:** {_format_link(current_link) if current_link else 'Not set'}",
            wrap=True, color=Colors.DARK
        )
        current_details_label = TextBlock(
            f"**Current Details:** {current_details if current_details else 'Not set'}",
            wrap=True, color=Colors.DARK
        )
        separator = TextBlock("─" * 40, color=Colors.LIGHT)

        input_link = Text(
            id="training_link",
            placeholder="Enter training/certification link",
            maxLength=500
        )
        input_details = Text(
            id="training_details",
            placeholder="Enter training details / description",
            maxLength=1000,
            isMultiline=True
        )

        body_items = [
            ColumnSet(columns=[Column(items=[title],   width=2)]),
            ColumnSet(columns=[Column(items=[warning], width=2)]),
            ColumnSet(columns=[Column(items=[member_info],             width=2)]),
            ColumnSet(columns=[Column(items=[separator],               width=2)]),
            ColumnSet(columns=[Column(items=[
                current_link_label, current_details_label
            ], width=2)]),
            ColumnSet(columns=[Column(items=[separator], width=2)]),
            ColumnSet(columns=[Column(items=[
                TextBlock("New Training Link:", weight=FontWeight.BOLDER),
                input_link,
                TextBlock("New Training Details:", weight=FontWeight.BOLDER),
                input_details
            ], width=2)]),
        ]

        body_items.extend(_build_exclude_list_block(excluded, all_members))

        submit = Submit(
            title="💾 Save & Start New Tracking",
            data={"callback_keyword": "save_training_link_callback"}
        )
        manage_exclude_btn = Submit(
            title="🚫 Manage Exclude List",
            data={"callback_keyword": "manage_exclude_list_callback"}
        )
        back_btn = Submit(
            title="🔙 Back",
            data={"callback_keyword": "back_to_training_card_callback"}
        )

        card = AdaptiveCard(
            body=body_items,
            actions=[submit, manage_exclude_btn, back_btn]
        )
        return response_from_adaptive_card(card)


# ══════════════════════════════════════════════
# Save Training Link → Reset → Notify
# ══════════════════════════════════════════════

class SaveTrainingLinkCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="save_training_link_callback",
            delete_previous_message=True
        )

    def _post_new_training_notification(self, data):
        try:
            api              = WebexAPI(access_token=BOT_ACCESS_TOKEN)
            training_link    = data.get("training_link", "Not set")
            training_details = data.get("training_details", "Not set")
            engineers        = data.get("engineers", {})

            link_md = "[{0}]({0})".format(training_link) \
                if training_link and training_link != "Not set" else "Not set"

            card_dict = {
                "type": "AdaptiveCard",
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "version": "1.2",
                "body": [
                    {"type": "TextBlock",
                     "text": "Training & Certification Tracker",
                     "weight": "Bolder", "size": "Large", "color": "Warning",
                     "horizontalAlignment": "Center"},
                    {"type": "TextBlock",
                     "text": "Hi Team,\n\nKindly request you to complete the below training "
                             "at the earliest and click **Mark as Completed** once finished.",
                     "wrap": True, "weight": "Bolder"},
                    {"type": "TextBlock",
                     "text": "----------------------------------------", "color": "Light"},
                    {"type": "TextBlock",
                     "text": "**Training Link:** " + link_md, "wrap": True},
                    {"type": "TextBlock",
                     "text": "**Training Details:** " + (training_details or "Not set"),
                     "wrap": True},
                    {"type": "TextBlock",
                     "text": "----------------------------------------", "color": "Light"},
                    {"type": "TextBlock",
                     "text": "**Team Members:** " + str(len(engineers)), "wrap": True},
                    {"type": "TextBlock",
                     "text": 'Click the "Mark as Completed" button below once you '
                             'have finished the training',
                     "wrap": True},
                ],
                "actions": [
                    {"type": "Action.Submit",
                     "title": "Mark as Completed",
                     "style": "positive",
                     "data": {"callback_keyword": "mark_self_completed_callback"}}
                ]
            }

            api.messages.create(
                roomId=ROOM_ID,
                text="New Training Alert - Please complete and mark as completed",
                attachments=[{
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": card_dict
                }]
            )
            log.info(f"Posted new training notification card to room {ROOM_ID}")

        except Exception as e:
            log.error(f"Failed to post new training notification: {e}")

    def execute(self, message, attachment_actions, activity):
        is_direct = _is_direct_message(activity)
        if not is_direct:
            return quote_info(
                "Training link can only be updated via direct message (1-on-1) with the bot."
            )

        new_link    = attachment_actions.inputs.get("training_link", "").strip()
        new_details = attachment_actions.inputs.get("training_details", "").strip()

        if not new_link:
            return quote_info("Please enter a training link.")

        _members_cache["last_fetched"] = None
        _members_cache["members"]      = []

        excluded_emails = list(_load_excluded_emails())

        data = _fresh_data(excluded_emails=excluded_emails)
        data["training_link"]    = new_link
        data["training_details"] = new_details or ""

        _save_data(data)
        log.info(
            f"New training link set: {new_link}. "
            f"Tracking {len(data['engineers'])} members. "
            f"Excluded: {excluded_emails}"
        )

        self._post_new_training_notification(data)
        return _build_checkpoint_card(data, is_direct=True)


# ══════════════════════════════════════════════
# Mark SELF as Completed
# ══════════════════════════════════════════════

class MarkSelfCompletedCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="mark_self_completed_callback",
            delete_previous_message=True
        )

    def _get_actor_info(self, activity):
        name = None
        email = None
        try:
            if isinstance(activity, dict):
                actor = activity.get("actor", {}) or {}
                name  = actor.get("displayName")
                email = (
                    actor.get("emailAddress")
                    or actor.get("email")
                    or (actor.get("entryUUID")
                        if "@" in str(actor.get("entryUUID", "")) else None)
                )
                if not email and isinstance(actor.get("emails"), list) and actor["emails"]:
                    email = actor["emails"][0]
        except Exception as e:
            log.error(f"Error extracting actor info: {e}")
        return name, email

    def _mention_pending_engineers(self, data):
        try:
            engineers     = data.get("engineers", {})
            training_link = data.get("training_link", "Not set")
            pending       = {n: i for n, i in engineers.items() if not i.get("completed", False)}

            if not pending:
                return

            api = WebexAPI(access_token=BOT_ACCESS_TOKEN)

            mention_parts = []
            for name, info in pending.items():
                email = info.get("email", "")
                if email:
                    mention_parts.append(f"<@personEmail:{email}|{name}>")
                else:
                    mention_parts.append(f"**{name}**")

            if len(mention_parts) == 1:
                mentions_str = mention_parts[0]
            elif len(mention_parts) == 2:
                mentions_str = f"{mention_parts[0]} and {mention_parts[1]}"
            else:
                mentions_str = ", ".join(mention_parts[:-1]) + " and " + mention_parts[-1]

            link_md = "[{0}]({0})".format(training_link) \
                if training_link and training_link != "Not set" else "Not set"

            api.messages.create(
                roomId=ROOM_ID,
                markdown=(
                    f"Hi {mentions_str},\n\n"
                    "Please complete the training and mark as completed.\n\n"
                    f"**Training Link:** {link_md}"
                )
            )
            log.info(f"Posted pending engineer reminder to room {ROOM_ID}")

        except Exception as e:
            log.error(f"Failed to post pending engineer mention: {e}")

    def execute(self, message, attachment_actions, activity):
        data = _load_data()
        data = _ensure_all_engineers(data)
        engineers = data.get("engineers", {})

        actor_name, actor_email = self._get_actor_info(activity)

        if not actor_email:
            try:
                actor_email = (
                    getattr(attachment_actions, "personEmail", None)
                    or getattr(attachment_actions, "person_email", None)
                )
            except Exception:
                pass

        log.info(f"MarkSelfCompleted clicked by name='{actor_name}', email='{actor_email}'")

        excluded_emails = _load_excluded_emails()
        if actor_email and actor_email.lower() in excluded_emails:
            msg = TextBlock(
                f"**{actor_name or 'You'}**, you are currently on the **exclude list** "
                "and are not being tracked for this training.\n\n"
                "If this is a mistake, please contact your admin.",
                wrap=True, color=Colors.WARNING, weight=FontWeight.BOLDER
            )
            card = AdaptiveCard(
                body=[ColumnSet(columns=[Column(items=[msg], width=2)])]
            )
            return response_from_adaptive_card(card)

        matched_name = None
        if actor_email:
            for name, info in engineers.items():
                if info.get("email", "").lower() == actor_email.lower():
                    matched_name = name
                    break
        if not matched_name and actor_name and actor_name in engineers:
            matched_name = actor_name

        is_direct = _is_direct_message(activity)

        if not matched_name:
            err = TextBlock(
                "Could not identify you as a tracked team member.\n\n"
                f"Detected: **{actor_name or 'Unknown'}** "
                f"({actor_email or 'no email'})\n\n"
                "Please contact your admin to be added to the tracker.",
                wrap=True, color=Colors.WARNING, weight=FontWeight.BOLDER
            )
            card = AdaptiveCard(
                body=[ColumnSet(columns=[Column(items=[err], width=2)])]
            )
            return response_from_adaptive_card(card)

        already_completed = data["engineers"][matched_name].get("completed", False)
        if already_completed:
            prev_time = data["engineers"][matched_name].get("updated_at", "")
            try:
                prev_time_fmt = datetime.fromisoformat(prev_time).strftime("%Y-%m-%d %H:%M")
            except Exception:
                prev_time_fmt = prev_time or "N/A"

            msg = TextBlock(
                f"**{matched_name}**, you have already marked this training as completed "
                f"on **{prev_time_fmt}**.\n\n"
                "Each engineer can mark completion only **once**. "
                "If this is a mistake, please contact your admin.",
                wrap=True, color=Colors.WARNING, weight=FontWeight.BOLDER
            )
            pending_info = TextBlock(
                "Other engineers who have not completed yet, please click the button below.",
                wrap=True, color=Colors.DARK
            )
            separator = TextBlock("─" * 40, color=Colors.LIGHT)
            mark_btn   = Submit(
                title="Mark as Completed",
                data={"callback_keyword": "mark_self_completed_callback"},
                style="positive"
            )
            card = AdaptiveCard(
                body=[
                    ColumnSet(columns=[Column(items=[msg],         width=2)]),
                    ColumnSet(columns=[Column(items=[separator],   width=2)]),
                    ColumnSet(columns=[Column(items=[pending_info], width=2)]),
                ],
                actions=[mark_btn]
            )
            return response_from_adaptive_card(card)

        data["engineers"][matched_name]["completed"]  = True
        data["engineers"][matched_name]["updated_at"] = datetime.now().isoformat()
        _save_data(data)
        log.info(f"{matched_name} marked themselves as COMPLETED.")

        self._mention_pending_engineers(data)
        return _build_checkpoint_card(data, is_direct=is_direct)


# ══════════════════════════════════════════════
# Training Status  ← MODIFIED: added Download Excel button
# ══════════════════════════════════════════════

class TrainingStatusCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="training_status_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        data = _load_data()
        data = _ensure_all_engineers(data)
        _save_data(data)

        engineers        = data.get("engineers", {})
        training_link    = data.get("training_link", "Not set")
        training_details = data.get("training_details", "Not set")
        excluded_emails  = set(e.lower() for e in data.get("excluded_emails", []))
        all_members      = _get_all_space_members_raw()

        title = TextBlock(
            "📊 Training Status",
            weight=FontWeight.BOLDER, size=FontSize.LARGE,
            horizontalAlignment=HorizontalAlignment.CENTER, color=Colors.DARK
        )
        link_text = TextBlock(
            f"**📎 Training Link:** {_format_link(training_link)}",
            wrap=True, color=Colors.DARK
        )
        details_text = TextBlock(
            f"**📝 Training Details:** {training_details or 'Not set'}",
            wrap=True, color=Colors.DARK
        )
        separator = TextBlock("─" * 40, color=Colors.LIGHT)

        completed = {n: i for n, i in engineers.items() if     i.get("completed", False)}
        pending   = {n: i for n, i in engineers.items() if not i.get("completed", False)}

        body_items = [
            ColumnSet(columns=[Column(items=[title],        width=2)]),
            ColumnSet(columns=[Column(items=[link_text],    width=2)]),
            ColumnSet(columns=[Column(items=[details_text], width=2)]),
            ColumnSet(columns=[Column(items=[separator],    width=2)]),
            ColumnSet(columns=[Column(items=[TextBlock(
                f"✅ Completed ({len(completed)}):",
                weight=FontWeight.BOLDER, color=Colors.GOOD
            )], width=2)]),
        ]

        if completed:
            body_items.append(ColumnSet(columns=[
                Column(items=[TextBlock("**Name**",         weight=FontWeight.BOLDER, color=Colors.DARK)], width=1),
                Column(items=[TextBlock("**Completed On**", weight=FontWeight.BOLDER, color=Colors.DARK)], width=1),
            ]))
            for name, info in completed.items():
                updated = info.get("updated_at", "")
                try:
                    updated = datetime.fromisoformat(updated).strftime("%Y-%m-%d %H:%M")
                except Exception:
                    pass
                body_items.append(ColumnSet(columns=[
                    Column(items=[TextBlock(f"✔ {name}", wrap=True, color=Colors.GOOD)],      width=1),
                    Column(items=[TextBlock(updated or "N/A", wrap=True, color=Colors.DARK)], width=1),
                ]))
        else:
            body_items.append(ColumnSet(columns=[Column(items=[
                TextBlock("  No engineers have completed yet.", wrap=True, color=Colors.DARK)
            ], width=2)]))

        body_items.append(ColumnSet(columns=[Column(items=[separator], width=2)]))
        body_items.append(ColumnSet(columns=[Column(items=[TextBlock(
            f"❌ Not Completed ({len(pending)}):",
            weight=FontWeight.BOLDER, color=Colors.GOOD
        )], width=2)]))

        if pending:
            for name in pending:
                body_items.append(ColumnSet(columns=[
                    Column(items=[TextBlock(f"✘ {name}", wrap=True, color=Colors.GOOD)], width=2),
                ]))
            body_items.extend([
                ColumnSet(columns=[Column(items=[separator], width=2)]),
                ColumnSet(columns=[Column(items=[TextBlock(
                    "⚠️ Remaining engineers above — please complete the training at the "
                    "earliest convenience and mark it as completed here!",
                    wrap=True, color=Colors.GOOD, weight=FontWeight.BOLDER
                )], width=2)]),
            ])
        else:
            body_items.append(ColumnSet(columns=[Column(items=[
                TextBlock("🎉 All engineers have completed!", wrap=True, color=Colors.GOOD)
            ], width=2)]))

        total = len(engineers)
        body_items.extend([
            ColumnSet(columns=[Column(items=[separator], width=2)]),
            ColumnSet(columns=[Column(items=[TextBlock(
                f"📊 Summary: {len(completed)}/{total} completed | {len(pending)}/{total} pending",
                wrap=True, weight=FontWeight.BOLDER, color=Colors.DARK
            )], width=2)]),
        ])

        body_items.extend(_build_exclude_list_block(excluded_emails, all_members))

        # ── Actions: Back + Download Excel ──
        back_btn = Submit(
            title="🔙 Back to Training Card",
            data={"callback_keyword": "back_to_training_card_callback"}
        )
        download_btn = Submit(
            title="📥 Download Completion Excel",
            data={"callback_keyword": "download_completion_excel_callback"}
        )

        card = AdaptiveCard(body=body_items, actions=[back_btn, download_btn])
        return response_from_adaptive_card(card)


# ══════════════════════════════════════════════
# Download Completion Excel  ← NEW
# ══════════════════════════════════════════════

class DownloadCompletionExcelCallback(Command):
    """
    Generates a styled Excel report of the training completion status
    and sends it as a file attachment to the requesting user's DM.
    """

    def __init__(self):
        super().__init__(
            card_callback_keyword="download_completion_excel_callback",
            delete_previous_message=True
        )

    def _get_actor_email(self, activity, attachment_actions):
        """Extract the requesting user's email from the activity payload."""
        actor_email = None
        try:
            if isinstance(activity, dict):
                actor = activity.get("actor", {}) or {}
                actor_email = (
                    actor.get("emailAddress")
                    or actor.get("email")
                )
                if not actor_email and isinstance(actor.get("emails"), list) and actor["emails"]:
                    actor_email = actor["emails"][0]
        except Exception as e:
            log.error(f"Error extracting actor email: {e}")

        if not actor_email:
            try:
                actor_email = (
                    getattr(attachment_actions, "personEmail", None)
                    or getattr(attachment_actions, "person_email", None)
                )
            except Exception:
                pass

        return actor_email

    def execute(self, message, attachment_actions, activity):
        try:
            # ── Load and sync data ──
            data = _load_data()
            data = _ensure_all_engineers(data)
            _save_data(data)

            engineers = data.get("engineers", {})
            if not engineers:
                return quote_info(
                    "⚠️ No engineer data found. "
                    "Please ensure the training tracker has been set up."
                )

            # ── Resolve requester email ──
            actor_email = self._get_actor_email(activity, attachment_actions)
            if not actor_email:
                return quote_info(
                    "❌ Could not determine your email address to send the report. "
                    "Please try again or contact your admin."
                )

            # ── Generate Excel bytes ──
            log.info(f"Generating Excel report requested by {actor_email}")
            excel_bytes = _generate_completion_excel(data)

            # ── Build a descriptive filename ──
            timestamp   = datetime.now().strftime("%Y%m%d_%H%M")
            file_name   = f"Training_Completion_Report_{timestamp}.xlsx"

            # ── Send file as a DM to the requesting user ──
            api = WebexAPI(access_token=BOT_ACCESS_TOKEN)
            api.messages.create(
                toPersonEmail=actor_email,
                text=(
                    "📊 Training Completion Status Report\n"
                    "Please find the attached Excel report with the current "
                    "training completion status of all tracked engineers."
                ),
                files=[(file_name, excel_bytes,
                        "application/vnd.openxmlformats-officedocument"
                        ".spreadsheetml.sheet")]
            )

            log.info(f"Excel report '{file_name}' sent to {actor_email}")

            # ── Confirmation card shown after sending ──
            completed_count = sum(
                1 for e in engineers.values() if e.get("completed", False)
            )
            pending_count   = len(engineers) - completed_count

            confirm_title = TextBlock(
                "✅ Excel Report Sent",
                weight=FontWeight.BOLDER, size=FontSize.LARGE,
                horizontalAlignment=HorizontalAlignment.CENTER,
                color=Colors.GOOD
            )
            confirm_msg = TextBlock(
                f"The training completion report **{file_name}** has been sent "
                f"to your Webex inbox (**{actor_email}**).",
                wrap=True, color=Colors.DARK
            )
            separator = TextBlock("─" * 40, color=Colors.LIGHT)
            summary_msg = TextBlock(
                f"📊 Report Summary: **{completed_count} completed** | "
                f"**{pending_count} pending** | **{len(engineers)} total tracked**",
                wrap=True, color=Colors.DARK, weight=FontWeight.BOLDER
            )
            note_msg = TextBlock(
                "💡 Open the file in Microsoft Excel or compatible spreadsheet "
                "application to view the full report.",
                wrap=True, color=Colors.DARK, isSubtle=True
            )

            body_items = [
                ColumnSet(columns=[Column(items=[confirm_title], width=2)]),
                ColumnSet(columns=[Column(items=[separator],     width=2)]),
                ColumnSet(columns=[Column(items=[confirm_msg],   width=2)]),
                ColumnSet(columns=[Column(items=[summary_msg],   width=2)]),
                ColumnSet(columns=[Column(items=[separator],     width=2)]),
                ColumnSet(columns=[Column(items=[note_msg],      width=2)]),
            ]

            back_btn = Submit(
                title="🔙 Back to Training Card",
                data={"callback_keyword": "back_to_training_card_callback"}
            )
            view_status_btn = Submit(
                title="📊 View Status Again",
                data={"callback_keyword": "training_status_callback"}
            )

            card = AdaptiveCard(
                body=body_items,
                actions=[back_btn, view_status_btn]
            )
            return response_from_adaptive_card(card)

        except Exception as e:
            log.error(f"DownloadCompletionExcelCallback error: {e}")
            return quote_info(
                f"❌ Failed to generate or send the Excel report: {e}\n\n"
                "Please check the bot logs or contact your admin."
            )


# ══════════════════════════════════════════════
# Remaining Engineers (Posts @mentions to Space)
# ══════════════════════════════════════════════

class RemainingEngineersCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="remaining_engineers_callback",
            delete_previous_message=True
        )

    def _build_pending_card_dict(self, pending, training_link, training_details, total):
        link_md = "[{0}]({0})".format(training_link) \
            if training_link and training_link != "Not set" else "Not set"
        return {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "body": [
                {"type": "TextBlock",
                 "text": "Pending Engineers - Action Required",
                 "weight": "Bolder", "size": "Medium", "color": "Warning",
                 "horizontalAlignment": "Center"},
                {"type": "TextBlock",
                 "text": "Request pending engineers to complete the training and mark as completed.",
                 "wrap": True},
                {"type": "TextBlock", "text": "─" * 40, "color": "Light"},
                {"type": "TextBlock", "text": "**Training Link:** " + link_md,  "wrap": True},
                {"type": "TextBlock",
                 "text": "**Training Details:** " + (training_details or "Not set"),
                 "wrap": True},
                {"type": "TextBlock", "text": "─" * 40, "color": "Light"},
                {"type": "TextBlock",
                 "text": f"Pending: {len(pending)}/{total} engineers have not completed.",
                 "weight": "Bolder", "color": "Warning", "wrap": True,
                 "horizontalAlignment": "Center"},
            ],
            "actions": [
                {"type": "Action.Submit",
                 "title": "Mark as Completed",
                 "style": "positive",
                 "data": {"callback_keyword": "mark_self_completed_callback"}}
            ]
        }

    def _post_to_space(self, pending, training_link, training_details, total):
        try:
            api = WebexAPI(access_token=BOT_ACCESS_TOKEN)

            mention_parts = []
            for name, info in pending.items():
                email = info.get("email", "")
                if email:
                    mention_parts.append(f"<@personEmail:{email}|{name}>")
                else:
                    mention_parts.append(f"**{name}**")

            if len(mention_parts) == 1:
                mentions_str = mention_parts[0]
            elif len(mention_parts) == 2:
                mentions_str = f"{mention_parts[0]} and {mention_parts[1]}"
            else:
                mentions_str = ", ".join(mention_parts[:-1]) + " and " + mention_parts[-1]

            link_md = "[{0}]({0})".format(training_link) \
                if training_link and training_link != "Not set" else "Not set"

            api.messages.create(
                roomId=ROOM_ID,
                markdown=(
                    f"Hi {mentions_str},\n\n"
                    "This is a gentle reminder that our records show the training is "
                    "still pending on your side. Kindly complete it at the earliest "
                    "and mark your status as Completed on the Training Tracker card."
                )
            )
            card_dict = self._build_pending_card_dict(
                pending, training_link, training_details, total
            )
            msg = api.messages.create(
                roomId=ROOM_ID,
                text="Pending Engineers - Action Required",
                attachments=[{
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": card_dict
                }]
            )
            log.info(f"Posted pending card to room {ROOM_ID} (id: {msg.id})")
            return True

        except Exception as e:
            log.error(f"Failed to post to space: {e}")
            return False

    def _send_confirmation_to_user(self, activity, pending_count, total, success):
        try:
            actor_email = None
            if isinstance(activity, dict):
                actor = activity.get("actor", {}) or {}
                actor_email = actor.get("emailAddress") or actor.get("email")
                if not actor_email and isinstance(actor.get("emails"), list) and actor["emails"]:
                    actor_email = actor["emails"][0]

            if not actor_email:
                return

            api = WebexAPI(access_token=BOT_ACCESS_TOKEN)
            if success:
                md = (
                    f"**Reminder Sent to Space**\n\n"
                    f"A reminder tagging **{pending_count} pending engineer(s)** has been "
                    f"posted to the Webex space along with a **Mark as Completed** button.\n\n"
                    f"{pending_count}/{total} engineers tagged in the space."
                )
            else:
                md = (
                    "**Failed to Send Reminder**\n\n"
                    "Something went wrong while posting the reminder. "
                    "Please check the bot logs."
                )
            api.messages.create(toPersonEmail=actor_email, markdown=md)

        except Exception as e:
            log.error(f"Failed to send DM confirmation: {e}")

    def execute(self, message, attachment_actions, activity):
        data = _load_data()
        data = _ensure_all_engineers(data)
        _save_data(data)
        engineers        = data.get("engineers", {})
        training_link    = data.get("training_link", "Not set")
        training_details = data.get("training_details", "Not set")

        pending = {n: i for n, i in engineers.items() if not i.get("completed", False)}
        total   = len(engineers)

        if not pending:
            title = TextBlock(
                "🎉 All engineers have completed the training!",
                weight=FontWeight.BOLDER, size=FontSize.MEDIUM,
                color=Colors.GOOD, horizontalAlignment=HorizontalAlignment.CENTER
            )
            back_btn = Submit(
                title="Back to Training Card",
                data={"callback_keyword": "back_to_training_card_callback"}
            )
            card = AdaptiveCard(
                body=[ColumnSet(columns=[Column(items=[title], width=2)])],
                actions=[back_btn]
            )
            return response_from_adaptive_card(card)

        success = self._post_to_space(pending, training_link, training_details, total)
        self._send_confirmation_to_user(activity, len(pending), total, success)

        is_direct = _is_direct_message(activity)
        return _build_checkpoint_card(data, is_direct=is_direct)


# ══════════════════════════════════════════════
# Scheduler
# ══════════════════════════════════════════════

class TrainingReminderScheduler:

    def __init__(self, webex_api: WebexAPI, room_id: str = None):
        self.api         = webex_api
        self.room_id     = room_id
        self._stop_event = threading.Event()

    def _send_reminders(self):
        if datetime.utcnow().weekday() > 4:
            return
        data = _load_data()
        data = _ensure_all_engineers(data)
        engineers        = data.get("engineers", {})
        training_link    = data.get("training_link", "N/A")
        training_details = data.get("training_details", "N/A")

        if not training_link or training_link == "N/A":
            log.info("No training link set. Skipping reminders.")
            return

        pending = {n: i for n, i in engineers.items() if not i.get("completed", False)}
        if not pending:
            log.info("All engineers completed. No reminders needed.")
            return

        lines = [
            "## ⏰ Training Completion Reminder", "",
            f"**Training Link:** [{training_link}]({training_link})",
            f"**Details:** {training_details}", "",
            "**Team, remaining engineers below — please complete the training "
            "at the earliest convenience and mark it as completed!**", "",
            "| # | Engineer | Email | Status |",
            "|---|----------|-------|--------|",
        ]
        for idx, (name, info) in enumerate(pending.items(), 1):
            lines.append(
                f"| {idx} | {name} | {info.get('email', 'N/A')} | ❌ Not Completed |"
            )
        lines.append("")
        lines.append("🔔 **Use the `training` command to update your status.**")

        if self.room_id:
            try:
                self.api.messages.create(roomId=self.room_id, markdown="\n".join(lines))
                log.info(f"Reminder posted to room {self.room_id}")
            except Exception as e:
                log.error(f"Failed to post reminder: {e}")

    def start(self):
        for day in ["monday", "tuesday", "wednesday", "thursday", "friday"]:
            getattr(schedule.every(), day).at("04:30").do(self._send_reminders)

        def _run():
            log.info("Scheduler started (10:00 AM IST, Mon-Fri)")
            while not self._stop_event.is_set():
                schedule.run_pending()
                time.sleep(30)

        threading.Thread(target=_run, daemon=True).start()
        log.info("Scheduler thread launched.")

    def stop(self):
        self._stop_event.set()
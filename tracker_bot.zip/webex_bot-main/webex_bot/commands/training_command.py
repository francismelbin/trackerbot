import logging
import json
import os
import threading
import schedule
import time
from datetime import datetime

from webexpythonsdk import WebexAPI
from webexpythonsdk.models.cards import (
    Colors, TextBlock, FontWeight, FontSize, Column, AdaptiveCard, ColumnSet,
    Text, Image, HorizontalAlignment
)
from webexpythonsdk.models.cards.actions import Submit

from webex_bot.formatting import quote_info
from webex_bot.models.command import Command
from webex_bot.models.response import response_from_adaptive_card

log = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# Persistent JSON data store
# ──────────────────────────────────────────────
DATA_FILE = "training_data.json"


def _load_data():
    """Load training data from JSON file."""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {
        "training_link": "",
        "training_details": "",
        "engineers": {}
    }


def _save_data(data):
    """Save training data to JSON file."""
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)


# ──────────────────────────────────────────────
# Main Training Command (card with 4 options)
# ──────────────────────────────────────────────
class TrainingCommand(Command):

    def __init__(self):
        super().__init__(
            command_keyword="training",
            help_message="Training & Certification Tracker – Manage training links, status, and certifications.",
            delete_previous_message=True,
            chained_commands=[
                UpdateTrainingLinkCallback(),
                UpdateTrainingStatusCallback(),
                CertificationStatusCallback(),
                CompletionStatusCallback(),
                SaveTrainingLinkCallback(),
                SaveTrainingStatusCallback(),
            ]
        )

    def pre_execute(self, message, attachment_actions, activity):
        image = Image(url="https://i.postimg.cc/2jMv5kqt/AS89975.jpg")
        text1 = TextBlock(
            "Loading Training Tracker...",
            weight=FontWeight.BOLDER, wrap=True,
            size=FontSize.DEFAULT,
            horizontalAlignment=HorizontalAlignment.CENTER,
            color=Colors.DARK
        )
        text2 = TextBlock(
            "Please wait while I prepare the training dashboard for you.",
            wrap=True, color=Colors.DARK
        )
        card = AdaptiveCard(
            body=[
                ColumnSet(columns=[Column(items=[image], width=2)]),
                ColumnSet(columns=[Column(items=[text1, text2])]),
            ]
        )
        return response_from_adaptive_card(card)

    def execute(self, message, attachment_actions, activity):
        """Display the main menu card with 4 action buttons."""

        title = TextBlock(
            "📋 Training & Certification Tracker",
            weight=FontWeight.BOLDER, size=FontSize.LARGE,
            horizontalAlignment=HorizontalAlignment.CENTER,
            color=Colors.DARK
        )
        subtitle = TextBlock(
            "Select an option below to manage training and certification records.",
            wrap=True, isSubtle=True,
            horizontalAlignment=HorizontalAlignment.CENTER
        )
        separator = TextBlock(" ", size=FontSize.SMALL)

        opt_a = TextBlock(
            "🔗 **Update Training Link** – Add or update the certification training link and details.",
            wrap=True, color=Colors.DARK
        )
        opt_b = TextBlock(
            "✅ **Update Training Status** – Mark your training as completed or not completed.",
            wrap=True, color=Colors.DARK
        )
        opt_c = TextBlock(
            "📊 **Certification Status** – View all engineers and their certification status.",
            wrap=True, color=Colors.DARK
        )
        opt_d = TextBlock(
            "⚠️ **Completion Status** – View engineers who have NOT completed the training.",
            wrap=True, color=Colors.DARK
        )

        btn_update_link = Submit(
            title="🔗 Update Training Link",
            data={"callback_keyword": "update_training_link_callback"}
        )
        btn_update_status = Submit(
            title="✅ Update Training Status",
            data={"callback_keyword": "update_training_status_callback"}
        )
        btn_cert_status = Submit(
            title="📊 Certification Status",
            data={"callback_keyword": "certification_status_callback"}
        )
        btn_completion = Submit(
            title="⚠️ Completion Status",
            data={"callback_keyword": "completion_status_callback"}
        )

        card = AdaptiveCard(
            body=[
                ColumnSet(columns=[Column(items=[title, subtitle], width=2)]),
                ColumnSet(columns=[Column(items=[separator])]),
                ColumnSet(columns=[Column(items=[opt_a, opt_b, opt_c, opt_d], width=2)]),
            ],
            actions=[btn_update_link, btn_update_status, btn_cert_status, btn_completion]
        )

        return response_from_adaptive_card(card)


# ──────────────────────────────────────────────
# Callback A: Show "Update Training Link" form
# ──────────────────────────────────────────────
class UpdateTrainingLinkCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="update_training_link_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        data = _load_data()

        title = TextBlock(
            "🔗 Update Training Link & Details",
            weight=FontWeight.BOLDER, size=FontSize.MEDIUM, color=Colors.DARK
        )
        current_link_label = TextBlock(
            f"**Current Link:** {data.get('training_link', 'Not set')}",
            wrap=True, color=Colors.DARK
        )
        current_details_label = TextBlock(
            f"**Current Details:** {data.get('training_details', 'Not set')}",
            wrap=True, color=Colors.DARK
        )

        input_link = Text(
            id="training_link",
            placeholder="Enter training/certification link",
            maxLength=500
        )
        input_details = Text(
            id="training_details",
            placeholder="Enter training details / description",
            maxLength=1000,
            isMultiline=True
        )

        submit = Submit(
            title="💾 Save Training Link",
            data={"callback_keyword": "save_training_link_callback"}
        )

        card = AdaptiveCard(
            body=[
                ColumnSet(columns=[Column(items=[title], width=2)]),
                ColumnSet(columns=[Column(items=[current_link_label, current_details_label], width=2)]),
                ColumnSet(columns=[Column(items=[
                    TextBlock("New Training Link:", weight=FontWeight.BOLDER),
                    input_link,
                    TextBlock("New Training Details:", weight=FontWeight.BOLDER),
                    input_details
                ], width=2)]),
            ],
            actions=[submit]
        )
        return response_from_adaptive_card(card)


class SaveTrainingLinkCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="save_training_link_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        new_link = attachment_actions.inputs.get("training_link", "").strip()
        new_details = attachment_actions.inputs.get("training_details", "").strip()

        data = _load_data()

        if new_link:
            data["training_link"] = new_link
        if new_details:
            data["training_details"] = new_details

        _save_data(data)

        result_text = "✅ **Training link/details updated successfully!**\n\n"
        result_text += f"**Link:** {data.get('training_link', 'Not set')}\n\n"
        result_text += f"**Details:** {data.get('training_details', 'Not set')}"

        return quote_info(result_text)


# ──────────────────────────────────────────────
# Callback B: Show "Update Training Status" form
# ──────────────────────────────────────────────
class UpdateTrainingStatusCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="update_training_status_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        engineer_email = "unknown"
        if isinstance(activity, dict):
            engineer_email = activity.get("actor", {}).get("emailAddress",
                            activity.get("actor", {}).get("id", "unknown"))

        data = _load_data()
        current_status = "Not Started"
        if engineer_email in data.get("engineers", {}):
            current_status = ("Completed ✅"
                              if data["engineers"][engineer_email].get("completed", False)
                              else "Not Completed ❌")

        title = TextBlock(
            "✅ Update Your Training Status",
            weight=FontWeight.BOLDER, size=FontSize.MEDIUM, color=Colors.DARK
        )
        status_text = TextBlock(
            f"**Your current status:** {current_status}",
            wrap=True, color=Colors.DARK
        )
        link_info = TextBlock(
            f"**Training Link:** {data.get('training_link', 'Not set yet')}",
            wrap=True, color=Colors.DARK
        )
        details_info = TextBlock(
            f"**Training Details:** {data.get('training_details', 'Not set yet')}",
            wrap=True, color=Colors.DARK
        )

        input_name = Text(
            id="engineer_name",
            placeholder="Enter your full name",
            maxLength=100
        )
        input_email = Text(
            id="engineer_email",
            placeholder="Enter your email address",
            maxLength=200
        )

        # ── Raw dictionary for ChoiceSet (SDK-version-safe) ──
        status_choices = {
            "type": "Input.ChoiceSet",
            "id": "training_completed",
            "style": "expanded",
            "choices": [
                {"title": "✅ Completed", "value": "true"},
                {"title": "❌ Not Completed", "value": "false"}
            ]
        }

        submit = Submit(
            title="💾 Save My Status",
            data={"callback_keyword": "save_training_status_callback"}
        )

        card = AdaptiveCard(
            body=[
                ColumnSet(columns=[Column(items=[title], width=2)]),
                ColumnSet(columns=[Column(items=[link_info, details_info], width=2)]),
                ColumnSet(columns=[Column(items=[status_text], width=2)]),
                ColumnSet(columns=[Column(items=[
                    TextBlock("Your Name:", weight=FontWeight.BOLDER),
                    input_name,
                    TextBlock("Your Email:", weight=FontWeight.BOLDER),
                    input_email,
                    TextBlock("Training Status:", weight=FontWeight.BOLDER),
                    status_choices,
                ], width=2)]),
            ],
            actions=[submit]
        )
        return response_from_adaptive_card(card)


class SaveTrainingStatusCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="save_training_status_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        engineer_name = attachment_actions.inputs.get("engineer_name", "").strip()
        engineer_email = attachment_actions.inputs.get("engineer_email", "").strip()
        completed_str = attachment_actions.inputs.get("training_completed", "false")

        if not engineer_name or not engineer_email:
            return quote_info("⚠️ **Please provide both your name and email address.**")

        completed = completed_str.lower() == "true"

        data = _load_data()
        if "engineers" not in data:
            data["engineers"] = {}

        data["engineers"][engineer_email] = {
            "name": engineer_name,
            "completed": completed,
            "updated_at": datetime.now().isoformat()
        }
        _save_data(data)

        status_emoji = "✅ Completed" if completed else "❌ Not Completed"
        return quote_info(
            f"💾 **Training status saved!**\n\n"
            f"**Name:** {engineer_name}\n\n"
            f"**Email:** {engineer_email}\n\n"
            f"**Status:** {status_emoji}"
        )


# ──────────────────────────────────────────────
# Callback C: Certification Status (all engineers)
# ──────────────────────────────────────────────
class CertificationStatusCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="certification_status_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        data = _load_data()
        engineers = data.get("engineers", {})

        title = TextBlock(
            "📊 Certification Status – All Engineers",
            weight=FontWeight.BOLDER, size=FontSize.MEDIUM, color=Colors.DARK
        )

        if not engineers:
            no_data = TextBlock(
                "No engineers have registered their status yet.",
                wrap=True, color=Colors.WARNING
            )
            card = AdaptiveCard(
                body=[
                    ColumnSet(columns=[Column(items=[title], width=2)]),
                    ColumnSet(columns=[Column(items=[no_data], width=2)]),
                ]
            )
            return response_from_adaptive_card(card)

        header_name = TextBlock("**Engineer Name**", weight=FontWeight.BOLDER, color=Colors.DARK)
        header_email = TextBlock("**Email**", weight=FontWeight.BOLDER, color=Colors.DARK)
        header_status = TextBlock("**Status**", weight=FontWeight.BOLDER, color=Colors.DARK)

        body_items = [
            ColumnSet(columns=[Column(items=[title], width=2)]),
            ColumnSet(columns=[
                Column(items=[header_name], width=1),
                Column(items=[header_email], width=1),
                Column(items=[header_status], width=1),
            ]),
        ]

        for email, info in engineers.items():
            name = info.get("name", "Unknown")
            completed = info.get("completed", False)
            status_label = "✅ Completed" if completed else "❌ Not Completed"
            status_color = Colors.GOOD if completed else Colors.ATTENTION

            row = ColumnSet(columns=[
                Column(items=[TextBlock(name, wrap=True, color=Colors.DARK)], width=1),
                Column(items=[TextBlock(email, wrap=True, color=Colors.DARK)], width=1),
                Column(items=[TextBlock(status_label, wrap=True, color=status_color)], width=1),
            ])
            body_items.append(row)

        total = len(engineers)
        completed_count = sum(1 for e in engineers.values() if e.get("completed", False))
        pending_count = total - completed_count

        summary = TextBlock(
            f"\n**Total:** {total} | **Completed:** {completed_count} | **Pending:** {pending_count}",
            wrap=True, weight=FontWeight.BOLDER, color=Colors.DARK
        )
        body_items.append(ColumnSet(columns=[Column(items=[summary], width=2)]))

        card = AdaptiveCard(body=body_items)
        return response_from_adaptive_card(card)


# ──────────────────────────────────────────────
# Callback D: Completion Status (only NOT completed)
# ──────────────────────────────────────────────
class CompletionStatusCallback(Command):

    def __init__(self):
        super().__init__(
            card_callback_keyword="completion_status_callback",
            delete_previous_message=True
        )

    def execute(self, message, attachment_actions, activity):
        data = _load_data()
        engineers = data.get("engineers", {})

        pending_engineers = {
            email: info for email, info in engineers.items()
            if not info.get("completed", False)
        }

        title = TextBlock(
            "⚠️ Engineers Who Have NOT Completed Training",
            weight=FontWeight.BOLDER, size=FontSize.MEDIUM, color=Colors.ATTENTION
        )

        if not pending_engineers:
            all_done = TextBlock(
                "🎉 All engineers have completed the training!",
                wrap=True, color=Colors.GOOD
            )
            card = AdaptiveCard(
                body=[
                    ColumnSet(columns=[Column(items=[title], width=2)]),
                    ColumnSet(columns=[Column(items=[all_done], width=2)]),
                ]
            )
            return response_from_adaptive_card(card)

        header_name = TextBlock("**Engineer Name**", weight=FontWeight.BOLDER, color=Colors.DARK)
        header_email = TextBlock("**Email**", weight=FontWeight.BOLDER, color=Colors.DARK)
        header_updated = TextBlock("**Last Updated**", weight=FontWeight.BOLDER, color=Colors.DARK)

        body_items = [
            ColumnSet(columns=[Column(items=[title], width=2)]),
            ColumnSet(columns=[
                Column(items=[header_name], width=1),
                Column(items=[header_email], width=1),
                Column(items=[header_updated], width=1),
            ]),
        ]

        for email, info in pending_engineers.items():
            name = info.get("name", "Unknown")
            updated_at = info.get("updated_at", "N/A")
            if updated_at != "N/A":
                try:
                    dt = datetime.fromisoformat(updated_at)
                    updated_at = dt.strftime("%Y-%m-%d %H:%M")
                except Exception:
                    pass

            row = ColumnSet(columns=[
                Column(items=[TextBlock(name, wrap=True, color=Colors.DARK)], width=1),
                Column(items=[TextBlock(email, wrap=True, color=Colors.DARK)], width=1),
                Column(items=[TextBlock(updated_at, wrap=True, color=Colors.DARK)], width=1),
            ])
            body_items.append(row)

        summary = TextBlock(
            f"\n**Total Pending:** {len(pending_engineers)}",
            wrap=True, weight=FontWeight.BOLDER, color=Colors.ATTENTION
        )
        body_items.append(ColumnSet(columns=[Column(items=[summary], width=2)]))

        card = AdaptiveCard(body=body_items)
        return response_from_adaptive_card(card)


# ──────────────────────────────────────────────
# Scheduled Report – 10 AM IST, Weekdays only
# ──────────────────────────────────────────────
class TrainingReminderScheduler:

    def __init__(self, webex_api: WebexAPI, room_id: str = None):
        self.api = webex_api
        self.room_id = room_id
        self._stop_event = threading.Event()

    def _send_reminders(self):
        today = datetime.utcnow().weekday()
        if today > 4:
            return

        data = _load_data()
        engineers = data.get("engineers", {})
        training_link = data.get("training_link", "N/A")
        training_details = data.get("training_details", "N/A")

        pending = {
            email: info for email, info in engineers.items()
            if not info.get("completed", False)
        }

        if not pending:
            log.info("All engineers have completed training. No reminders needed.")
            return

        report_lines = [
            "## ⏰ Training Completion Reminder",
            "",
            f"**Training Link:** {training_link}",
            f"**Details:** {training_details}",
            "",
            "The following engineers have **NOT** completed the required training:",
            "",
            "| # | Name | Email |",
            "|---|------|-------|",
        ]

        for idx, (email, info) in enumerate(pending.items(), 1):
            name = info.get("name", "Unknown")
            report_lines.append(f"| {idx} | {name} | {email} |")

        report_lines.append("")
        report_lines.append(
            "🔔 **Please complete the training at your earliest convenience.** "
            "Use the `training` command in this bot to update your status."
        )

        report_message = "\n".join(report_lines)

        if self.room_id:
            try:
                self.api.messages.create(
                    roomId=self.room_id,
                    markdown=report_message
                )
                log.info(f"Training reminder posted to room {self.room_id}")
            except Exception as e:
                log.error(f"Failed to post reminder to room: {e}")

        for email, info in pending.items():
            personal_msg = (
                f"Hi **{info.get('name', 'Engineer')}**,\n\n"
                f"This is an automated reminder that you have **not yet completed** "
                f"the required training.\n\n"
                f"**Training Link:** {training_link}\n\n"
                f"**Details:** {training_details}\n\n"
                f"Please complete the training and update your status using the "
                f"`training` command.\n\n"
                f"Thank you! 🙏"
            )
            try:
                self.api.messages.create(
                    toPersonEmail=email,
                    markdown=personal_msg
                )
                log.info(f"Reminder sent to {email}")
            except Exception as e:
                log.error(f"Failed to send reminder to {email}: {e}")

    def start(self):
        schedule.every().monday.at("04:30").do(self._send_reminders)
        schedule.every().tuesday.at("04:30").do(self._send_reminders)
        schedule.every().wednesday.at("04:30").do(self._send_reminders)
        schedule.every().thursday.at("04:30").do(self._send_reminders)
        schedule.every().friday.at("04:30").do(self._send_reminders)

        def _run():
            log.info("Training Reminder Scheduler started (10:00 AM IST, Mon-Fri)")
            while not self._stop_event.is_set():
                schedule.run_pending()
                time.sleep(30)

        thread = threading.Thread(target=_run, daemon=True)
        thread.start()
        log.info("Scheduler thread launched.")

    def stop(self):
        self._stop_event.set()
        log.info("Training Reminder Scheduler stopped.")